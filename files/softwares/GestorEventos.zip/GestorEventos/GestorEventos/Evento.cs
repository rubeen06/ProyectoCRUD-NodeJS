﻿using System;
namespace GestorEventos
{
    public class Evento
    {
        public string Nombre { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime Fin { get; set; }
        public string Lugar { get; set; }
        public string Tipo { get; set; }
        public string SubTipo { get; set; }
        public uint EntradasDisponibles { get; set; }
        public string Descripcion { get; set; }

        /**
         * Permite obtener datos de ejemplo para el examen
         */
        public static List<Evento> getEventos()
        {
            List<Evento> eventos = new List<Evento>();

            eventos.Add(new Evento { Nombre = "Examen 2º Trimestre Desarrollo de Interfaces", Inicio = DateTime.Now.Date, Fin = DateTime.Now.Date, Lugar = "Aula DAM2", Descripcion = "El examen de DAM2", Tipo = "Examen", SubTipo = "DAM" });
            eventos.Add(new Evento { Nombre = "Examen 2º Trimestre Desarrollo Web Entorno Cliente", Inicio = DateTime.Now.Date.AddDays(3), Fin = DateTime.Now.Date.AddDays(3), Lugar = "Aula DAW2", Descripcion = "El examen de DAW2", Tipo = "Examen", SubTipo = "DAW" });
            eventos.Add(new Evento { Nombre = "MadCool 2024", Inicio = new DateTime(2024, 7, 10), Fin = new DateTime(2024, 7, 13), Lugar = "Madrid", Descripcion = "Mad Cool es un festival de música que se realiza en Madrid desde el año 2016. El arte, la moda, la gastronomía y el turismo se unen eclécticamente en este festival.", Tipo = "Festival de Música", SubTipo = "Variado" });
            eventos.Add(new Evento { Nombre = "Beat Festival 2024", Inicio = new DateTime(2024, 5, 10), Fin = new DateTime(2024, 5, 11), Lugar = "Toledo", Descripcion = "Toledo Beat Festival repite tras su primera cita en 2023, y celebrará su segunda edición los días 10 y 11 de mayo.", Tipo = "Festival de Música", SubTipo = "Indie" });
            eventos.Add(new Evento { Nombre = "FIB 2024", Inicio = new DateTime(2024, 7, 13), Fin = new DateTime(2024, 7, 16), Lugar = "Benicassim", Descripcion = "El Festival Internacional de Benicasim es un festival de música, pop, rock, indie, electrónica y de otros tipos, además de otras actividades que se celebra en la localidad de Benicasim cada año desde 1995.", Tipo = "Festival de Música", SubTipo = "Variado" });
            eventos.Add(new Evento { Nombre = "Medusa Festival 2024", Inicio = new DateTime(2024, 8, 7), Fin = new DateTime(2024, 8, 12), Lugar = "Cullera", Descripcion = "MEDUSA FESTIVAL DEL 7 AL 12 DE AGOSTO DEL 2024.", Tipo = "Festival de Música", SubTipo = "Electrónica" });
            eventos.Add(new Evento { Nombre = "Tomorrowland 2024 Weekend 1", Inicio = new DateTime(2024, 7, 19), Fin = new DateTime(2024, 7, 22), Lugar = "Bélgica", Descripcion = "Tomorrowland es un festival de música electrónica de baile celebrado anualmente en la localidad belga de Boom.", Tipo = "Festival de Música", SubTipo = "Electrónica" });
            eventos.Add(new Evento { Nombre = "Tomorrowland 2024 Weekend 2", Inicio = new DateTime(2024, 7, 26), Fin = new DateTime(2024, 7, 29), Lugar = "Bélgica", Descripcion = "Tomorrowland es un festival de música electrónica de baile celebrado anualmente en la localidad belga de Boom.", Tipo = "Festival de Música", SubTipo = "Electrónica" });
            eventos.Add(new Evento { Nombre = "BBF Madrid 2024", Inicio = new DateTime(2024, 7, 14), Fin = new DateTime(2024, 7, 14), Lugar = "Madrid", Descripcion = "El festival BBF llega por primera vez a Madrid el 14 de julio de 2024.", Tipo = "Festival de Música", SubTipo = "Electrónica" });

            Random rnd = new Random();

            foreach (var evento in eventos)
            {
                evento.EntradasDisponibles = (uint)rnd.Next(20);
            }

            eventos.Add(new Evento { Nombre = "El evento del milenio", Inicio = new DateTime(2000, 1, 1), Fin = new DateTime(3000, 1, 1), Lugar = "Todos", Descripcion = "El evento que dura un milenio entero.", Tipo = "Otros", SubTipo = "Otros" });


            return eventos;
        }
    }
}
