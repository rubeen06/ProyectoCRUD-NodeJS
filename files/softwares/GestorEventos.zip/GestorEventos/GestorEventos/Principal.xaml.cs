﻿using System.Windows;
using System.Windows.Controls;

namespace GestorEventos
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Principal : Window
    {
        private List<Evento> eventos;
        public Principal()
        {
            InitializeComponent();
            this.eventos = Evento.getEventos();
        }


        /**
         * El formulario de alta y modificación de eventos llamará a esta función
         * 
         * @evento: El objeto Evento nuevo / modificado.
         * @nuevo: Indica si el evento es nuevo o no (formulario de alta, o modificación).
         * 
         */
        private void CallbackFormularioEventos(Evento evento, bool nuevo)
        {
            // TODO: Pista, si el elemento es nuevo, tienes que añadirlo a la colección
            // Pero si el elemento no es nuevo, probablemente solo tengas que refrescar la vista.
            // Refrescar vista: listViewEventos.Items.Refresh();
            // Al añadir un elemento nuevo, también es posible que deban actualizarse los filtros de tipo/subtipo.
        }

        /**
         * El botón de "añadir evento" deberá llamar a esta función.
         * La función muestra el formulario de alta y edición de eventos.
         * 
         * Como no se le pasa ningún evento al formulario, creará uno nuevo.
         */
        private void NuevoEvento_Click(object sender, RoutedEventArgs e)
        {
            FormularioEventos fe = new FormularioEventos(CallbackFormularioEventos);
            fe.Show();
        }

        /**
         * El botón de "modificar evento" deberá llamar a esta función.
         * La función muestra el formulario de alta y edición de eventos.
         * 
         * Debemos pasarle al formulario (en el constructor) el evento a modificar.
         */
        private void ModificarEvento_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Elige aquí el evento que esté seleccionado en tu lista de eventos
            //Evento eventoSeleccionado = (Evento)lv.SelectedItem;
            //FormularioEventos fe = new FormularioEventos(eventoSeleccionado, CallbackFormularioEventos);
            //fe.Show();
        }
    }
}