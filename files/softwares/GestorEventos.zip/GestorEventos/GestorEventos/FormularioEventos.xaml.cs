﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;


namespace GestorEventos
{
    /// <summary>
    /// Lógica de interacción para UserControl1.xaml
    /// </summary>
    partial class FormularioEventos : Window
    {
        private Evento evento;
        private Action<Evento, bool> callback;
        private bool nuevo;
        public FormularioEventos(Action<Evento, bool> callback)
        {
            InitializeComponent();
            Titulo.Text = "Nuevo evento";
            evento = new Evento();
            this.nuevo = true;
            this.callback = callback;
        }

        public FormularioEventos(Evento evento, Action<Evento, bool> callback)
        {
            InitializeComponent();
            Titulo.Text = "Modificando evento";
            nombre.Text = evento.Nombre;
            lugar.Text = evento.Lugar;
            fechaInicio.SelectedDate = evento.Inicio;
            fechaFin.SelectedDate = evento.Fin;
            tipo.Text = evento.Tipo;
            subtipo.Text = evento.SubTipo;
            entradasDisponibles.Text = evento.EntradasDisponibles.ToString();
            descripcion.Text = evento.Descripcion;

            this.evento = evento;
            this.nuevo = false;
            this.callback = callback;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if(nombre.Text.Equals(string.Empty) 
                || lugar.Text.Equals(string.Empty)
                || tipo.Text.Equals(string.Empty)
                || subtipo.Text.Equals(string.Empty)
                || entradasDisponibles.Text.Equals(string.Empty)
                || !fechaInicio.SelectedDate.HasValue
                || !fechaFin.SelectedDate.HasValue
                )
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error de validación", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if(!uint.TryParse(entradasDisponibles.Text, out uint entradasDisponiblesUint))
            {
                MessageBox.Show("El valor de \"Entradas disponibles\" debe ser numérico positivo.", "Error de validación", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            evento.Nombre = nombre.Text;
            evento.Lugar = lugar.Text;
            evento.Inicio = fechaInicio.SelectedDate.Value;
            evento.Fin = fechaFin.SelectedDate.Value;
            evento.Tipo = tipo.Text;
            evento.SubTipo = subtipo.Text;
            evento.EntradasDisponibles = entradasDisponiblesUint;
            evento.Descripcion = descripcion.Text;
            this.callback(evento, nuevo);
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
