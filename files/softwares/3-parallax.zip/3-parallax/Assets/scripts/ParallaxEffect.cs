using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxEffect : MonoBehaviour
{
  public float velocidad;
  private MeshRenderer imagen;

  void Start()
  {
    imagen = this.GetComponent<MeshRenderer>();
  }

  void Update()
  {
    imagen.material.mainTextureOffset = new Vector2(Time.time * velocidad, 0);
  }
}
