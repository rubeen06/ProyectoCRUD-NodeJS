package ejercicioZ1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

/**
 * Clase Cliente
 * 
 */
public class Cliente {
  static final String HOST = "localhost";
  static final int PUERTO = 6000;

  public static void main(String[] args) {
    try {
      Socket cliente = new Socket(HOST, PUERTO);

      DataInputStream flujoEntrada = new DataInputStream(cliente.getInputStream());
      DataOutputStream flujoSalida = new DataOutputStream(cliente.getOutputStream());

      // Enviar nombre del cliente
      String mensaje1 = flujoEntrada.readUTF();
      System.out.println(mensaje1);

      Scanner sc = new Scanner(System.in);
      boolean exito = false;

      Gson gson;
      String respuesta;

      do {
        String comando = sc.nextLine().toUpperCase();

        switch (comando) {
          case "LIST":
            flujoSalida.writeUTF(comando);
            respuesta = flujoEntrada.readUTF();
            try {
              gson = new Gson();
              List<Tarea> listaTareas = gson.fromJson(respuesta, new TypeToken<List<Tarea>>() {}.getType());

              for (Tarea tarea : listaTareas) {
                System.out.println(tarea);
              }
            } catch (JsonSyntaxException e) {
              System.out.println(respuesta);
            }

            break;

          case "POP":
            flujoSalida.writeUTF(comando);
            respuesta = flujoEntrada.readUTF();
            try {
              gson = new Gson();
              Tarea tarea = gson.fromJson(respuesta, Tarea.class);
              System.out.println(tarea);
            } catch (JsonSyntaxException e) {
              System.out.println(respuesta);
            }

            break;

          case "EXIT":
            flujoSalida.writeUTF(comando);
            exito = true;
            break;

          default:
            System.out.println("Comando erróneo, intentelo de nuevo");
        }

      } while (!exito);

      sc.close();

      flujoEntrada.close();
      flujoSalida.close();
      cliente.close();

    } catch (Exception e) {
      e.printStackTrace();
    }

  }

}
