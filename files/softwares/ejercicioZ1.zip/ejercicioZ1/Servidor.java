package ejercicioZ1;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;


public class Servidor {

  public static void main(String[] arg) throws IOException {
    final int PUERTO = 6000; // puerto

    List<Tarea> listaTareas = new ArrayList<Tarea>();

    listaTareas.add(new Tarea(90, "tarea 1", new Date()));
    listaTareas.add(new Tarea(31, "tarea 2", new Date()));
    listaTareas.add(new Tarea(8, "tarea 3", new Date()));
    listaTareas.add(new Tarea(43, "tarea 4", new Date()));

    try {
      ServerSocket servidor = new ServerSocket(PUERTO);

      Socket cliente = servidor.accept();

      DataOutputStream flujoSalida = new DataOutputStream(cliente.getOutputStream());
      DataInputStream flujoEntrada = new DataInputStream(cliente.getInputStream());

      flujoSalida.writeUTF("¿LIST, POP, EXIT?");

      boolean fin = false;

      do {
        String comando = flujoEntrada.readUTF().toUpperCase();

        String respuesta;
        Gson gson;

        switch (comando) {
          case "LIST":
            if (listaTareas.size() > 0) {
              gson = new Gson();
              respuesta = gson.toJson(listaTareas);
            } else {
              respuesta = "Lista vacía";
            }
            flujoSalida.writeUTF(respuesta);
            break;
          case "POP":
            if (listaTareas.size() > 0) {
              gson = new Gson();
              respuesta = gson.toJson(listaTareas.remove(0));
            } else {
              respuesta = "No hay tareas";
            }
            flujoSalida.writeUTF(respuesta);
            break;
          case "EXIT":
            fin = true;
            break;
          default:
        }
      } while (!fin);

      flujoEntrada.close();
      flujoSalida.close();
      cliente.close();
      servidor.close();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}