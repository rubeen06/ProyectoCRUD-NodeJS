package ejercicioZ1;

import java.util.Date;

public class Tarea {
  public int id;
  public String contenido;
  public Date fecha;

  public Tarea(int id, String contenido, Date fecha) {
    this.id = id;
    this.contenido = contenido;
    this.fecha = fecha;
  }

  public String toString() {
    return "ID: " + this.id + ",\tFECHA: " + this.fecha + ",\tCONTENIDO: " + this.contenido;
  }
}
